package com.elevenware.fakeid.demos.backchannel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackchannelApplicationTests {

	@Test
	void contextLoads() {
	}

}
